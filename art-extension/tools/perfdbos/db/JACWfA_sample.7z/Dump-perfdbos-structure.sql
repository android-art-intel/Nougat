CREATE DATABASE  IF NOT EXISTS `perfdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `perfdb`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: perfdb
-- ------------------------------------------------------
-- Server version	5.5.53-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data_builds`
--

DROP TABLE IF EXISTS `data_builds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_builds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `build` varchar(128) NOT NULL,
  `run_date` timestamp NULL DEFAULT NULL,
  `buildreleaseversion` varchar(45) DEFAULT NULL,
  `year` int(11) NOT NULL DEFAULT '2015',
  `week` varchar(32) NOT NULL,
  `branch` int(11) NOT NULL,
  `device` int(11) DEFAULT NULL,
  `mode` varchar(16) NOT NULL DEFAULT '',
  `extraopts` varchar(45) NOT NULL DEFAULT '',
  `backend` int(11) DEFAULT NULL,
  `build_type` varchar(10) NOT NULL,
  `day` varchar(16) NOT NULL,
  `source` varchar(16) DEFAULT NULL,
  `evaluatedby` varchar(32) DEFAULT NULL,
  `int_build_num` int(11) DEFAULT NULL,
  `int_patch_num` int(11) DEFAULT NULL,
  `comment` varchar(256) NOT NULL DEFAULT '',
  `basebuild` int(11) DEFAULT NULL,
  `data_type` varchar(45) DEFAULT 'other' COMMENT 'ENUM(''testresult'',''target'',''competitiondata'',''other'')',
  PRIMARY KEY (`id`),
  UNIQUE KEY `build_UNIQUE` (`build`,`device`,`mode`,`backend`,`branch`,`source`),
  KEY `fk_branch_idx` (`branch`),
  KEY `fk_devices_idx` (`device`),
  KEY `fk_backend_idx` (`backend`),
  KEY `fk_mode_idx` (`mode`),
  KEY `fk_build_type_idx` (`build_type`),
  CONSTRAINT `builds_backend` FOREIGN KEY (`backend`) REFERENCES `list_backends` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `builds_branch` FOREIGN KEY (`branch`) REFERENCES `list_branches` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `builds_devices` FOREIGN KEY (`device`) REFERENCES `list_devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_hosts`
--

DROP TABLE IF EXISTS `data_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostname_UNIQUE` (`hostname`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_results`
--

DROP TABLE IF EXISTS `data_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_results` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `build` int(11) NOT NULL,
  `directory` int(11) DEFAULT NULL,
  `benchmark` int(11) NOT NULL,
  `workload` int(11) NOT NULL,
  `filtered` tinyint(1) NOT NULL DEFAULT '0',
  `value` decimal(30,4) NOT NULL,
  `benchmark_internal_version` varchar(45) NOT NULL DEFAULT '',
  `ismedian` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `results_builds_idx` (`build`),
  KEY `results_benchmarks_idx` (`benchmark`),
  KEY `results_directories_idx` (`directory`),
  KEY `results_workloads_idx` (`workload`),
  CONSTRAINT `results_benchmarks` FOREIGN KEY (`benchmark`) REFERENCES `list_benchmarks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `results_builds` FOREIGN KEY (`build`) REFERENCES `data_builds` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `results_run_props` FOREIGN KEY (`directory`) REFERENCES `data_run_props` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `results_workloads` FOREIGN KEY (`workload`) REFERENCES `list_workloads` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3417 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_run_props`
--

DROP TABLE IF EXISTS `data_run_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_run_props` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(196) NOT NULL COMMENT 'directory name',
  `host` int(11) DEFAULT NULL COMMENT 'link on hostname',
  `cores_freq_min` varchar(256) DEFAULT NULL COMMENT 'Min frequency of cores',
  `cores_freq_max` varchar(256) DEFAULT NULL COMMENT 'Max frequency of cores',
  `cores_freq_avg` varchar(256) DEFAULT NULL COMMENT 'AVG frequency of cores',
  `cpu_freq_min` float DEFAULT NULL COMMENT 'Sum of cores Min frequencies',
  `cpu_freq_max` float DEFAULT NULL COMMENT 'Sum of cores Max frequencies',
  `cpu_freq_avg` float DEFAULT NULL COMMENT 'Sum of cores AVG frequencies',
  `cpu_freq_histo` varchar(512) DEFAULT NULL COMMENT 'Frequencies histogram',
  `cpu_corenum` tinyint(4) DEFAULT NULL COMMENT 'Number of cores',
  `cpu_governer` varchar(128) DEFAULT NULL COMMENT 'Used CPU governer',
  `cpu_temp_start` int(11) DEFAULT NULL COMMENT 'CPU’s start temperature',
  `cpu_temp_end` int(11) DEFAULT NULL COMMENT 'CPU’s end temperature',
  `cpu_temp_min` int(11) DEFAULT NULL COMMENT 'CPU’s min temperature',
  `cpu_temp_max` int(11) DEFAULT NULL COMMENT 'CPU’s Max temperature',
  `cpu_temp_avg` float DEFAULT NULL COMMENT 'CPU’s Avg temperature',
  `cpu_throttle_count` int(11) DEFAULT NULL COMMENT 'Throttling events count',
  `env_temp` int(11) DEFAULT NULL COMMENT 'Environment temperature',
  `time_length` int(11) DEFAULT NULL COMMENT 'Execution time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `directory_UNIQUE` (`directory`),
  KEY `fk_hostname` (`host`),
  CONSTRAINT `fk_hostname` FOREIGN KEY (`host`) REFERENCES `data_hosts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_backends`
--

DROP TABLE IF EXISTS `list_backends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_backends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT 'backend name',
  `bitdepth` int(11) NOT NULL COMMENT '32 or 64 bits',
  `vm_type` varchar(45) DEFAULT NULL COMMENT 'used by results parser',
  `vm_backend` varchar(45) DEFAULT NULL COMMENT 'used by results parser',
  `vm_mode` varchar(45) DEFAULT NULL COMMENT 'used by results parser',
  `comment` varchar(45) DEFAULT NULL COMMENT 'not used',
  `enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'hiding obsolete backends',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_benchmarks`
--

DROP TABLE IF EXISTS `list_benchmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_benchmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT 'used for parsing results and displaying data',
  `version` varchar(45) NOT NULL COMMENT 'benchmarks version',
  `fullname` varchar(45) DEFAULT '' COMMENT 'can be used to display a full name',
  `URL` varchar(255) DEFAULT '' COMMENT 'URL with benchmarks description',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'benchmark support will be turned off in case of 0 value',
  `isKPI` tinyint(1) DEFAULT '0' COMMENT 'is in KeyPerformanceIndicators group or not',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`,`name`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_branches`
--

DROP TABLE IF EXISTS `list_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT 'branch name',
  `alias` varchar(128) DEFAULT NULL COMMENT 'second name of branch',
  `comment` varchar(45) DEFAULT NULL COMMENT 'branch description - currently not used in GUI',
  `archived` tinyint(1) DEFAULT '0' COMMENT 'move branch to archive',
  `use_bronze_silver_detection` tinyint(1) DEFAULT '0' COMMENT 'used for results parsing (checks for considers “[branch_name]” and “[branch_name]_bronze” as the same branch and branch is silver by default',
  `inverse_detection` tinyint(1) DEFAULT '0' COMMENT '''branch is bronze by default, expects _silver postfix for silver data',
  PRIMARY KEY (`id`,`name`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_devices`
--

DROP TABLE IF EXISTS `list_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT 'device name',
  `revision` varchar(45) DEFAULT NULL COMMENT 'device revision',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'hides unused devices from the site',
  `comment` varchar(128) DEFAULT NULL COMMENT 'comment - not used',
  `cpu` varchar(128) DEFAULT NULL,
  `devicegroup` int(11) NOT NULL COMMENT 'devices can be gathered in groups and all results from grouped devices will be combined',
  `mainingroup` tinyint(1) DEFAULT NULL COMMENT 'main device in group',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_workloads`
--

DROP TABLE IF EXISTS `list_workloads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_workloads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `benchmark` int(11) NOT NULL COMMENT 'link to benchmark which contains current workload',
  `name` varchar(128) NOT NULL COMMENT 'workload name (used in results parsing and displaying)',
  `order` int(11) DEFAULT '100' COMMENT 'display ordering control',
  `ismain` tinyint(1) DEFAULT '0' COMMENT 'marks the main workload(score) of benchmark',
  `lessisbetter` tinyint(1) NOT NULL COMMENT 'Switches: higher or lower score is better',
  `group` varchar(45) DEFAULT NULL COMMENT 'allows grouping several workloads on weekly report page',
  `criteria` varchar(16) DEFAULT 'median' COMMENT 'which score to select median/min/ma',
  `JPSPrimary` tinyint(1) DEFAULT '0' COMMENT 'is in JavaPerformanceSuitePrimary group or not',
  `float_value` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'type of score value int or float',
  `calculate` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'is it a calculatable score or a fixed value',
  PRIMARY KEY (`id`),
  KEY `fk_benchmark_idx` (`benchmark`),
  CONSTRAINT `benchmark` FOREIGN KEY (`benchmark`) REFERENCES `list_benchmarks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_currentvariabilityvalues`
--

DROP TABLE IF EXISTS `tmp_currentvariabilityvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_currentvariabilityvalues` (
  `variability` float NOT NULL,
  `benchmark` tinyint(4) NOT NULL,
  `workload` int(11) NOT NULL,
  `worder` int(11) NOT NULL,
  `source` varchar(10) NOT NULL,
  `minvariability` float NOT NULL,
  `maxvariability` float NOT NULL,
  `int_build_num` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `backend` int(11) NOT NULL,
  `device` int(11) NOT NULL,
  `mode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_variabilityvalues`
--

DROP TABLE IF EXISTS `tmp_variabilityvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_variabilityvalues` (
  `build` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `backend` int(11) NOT NULL,
  `device` int(11) NOT NULL,
  `int_build_num` int(11) NOT NULL,
  `mode` varchar(10) NOT NULL,
  `source` varchar(10) NOT NULL,
  `benchmark` tinyint(4) NOT NULL,
  `workload` int(11) NOT NULL,
  `worder` int(11) NOT NULL,
  `variability` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `variability_foreachbuild`
--

DROP TABLE IF EXISTS `variability_foreachbuild`;
/*!50001 DROP VIEW IF EXISTS `variability_foreachbuild`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `variability_foreachbuild` AS SELECT 
 1 AS `build`,
 1 AS `branch`,
 1 AS `backend`,
 1 AS `device`,
 1 AS `int_build_num`,
 1 AS `mode`,
 1 AS `source`,
 1 AS `benchmarkid`,
 1 AS `workloadid`,
 1 AS `worder`,
 1 AS `variability`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `variability_weekparams`
--

DROP TABLE IF EXISTS `variability_weekparams`;
/*!50001 DROP VIEW IF EXISTS `variability_weekparams`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `variability_weekparams` AS SELECT 
 1 AS `maxweek`,
 1 AS `minweek`,
 1 AS `branch`,
 1 AS `backend`,
 1 AS `device`,
 1 AS `mode`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `variability_weeksubparams`
--

DROP TABLE IF EXISTS `variability_weeksubparams`;
/*!50001 DROP VIEW IF EXISTS `variability_weeksubparams`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `variability_weeksubparams` AS SELECT 
 1 AS `branch`,
 1 AS `backend`,
 1 AS `device`,
 1 AS `mode`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_allresults`
--

DROP TABLE IF EXISTS `view_allresults`;
/*!50001 DROP VIEW IF EXISTS `view_allresults`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_allresults` AS SELECT 
 1 AS `build`,
 1 AS `year`,
 1 AS `week`,
 1 AS `branch`,
 1 AS `device`,
 1 AS `devicegroup`,
 1 AS `directory`,
 1 AS `directoryid`,
 1 AS `hostname`,
 1 AS `benchmark`,
 1 AS `benchmarkid`,
 1 AS `version`,
 1 AS `workload`,
 1 AS `workloadid`,
 1 AS `worder`,
 1 AS `ismain`,
 1 AS `result`,
 1 AS `ismedian`,
 1 AS `mode`,
 1 AS `extraopts`,
 1 AS `backend`,
 1 AS `filtered`,
 1 AS `buildid`,
 1 AS `deviceid`,
 1 AS `buildreleaseversion`,
 1 AS `backendid`,
 1 AS `branchid`,
 1 AS `source`,
 1 AS `lessisbetter`,
 1 AS `criteria`,
 1 AS `isKPI`,
 1 AS `wgroup`,
 1 AS `build_type`,
 1 AS `float_value`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_filteredresults`
--

DROP TABLE IF EXISTS `view_filteredresults`;
/*!50001 DROP VIEW IF EXISTS `view_filteredresults`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_filteredresults` AS SELECT 
 1 AS `build`,
 1 AS `year`,
 1 AS `week`,
 1 AS `branch`,
 1 AS `device`,
 1 AS `devicegroup`,
 1 AS `directory`,
 1 AS `hostname`,
 1 AS `benchmark`,
 1 AS `benchmarkid`,
 1 AS `version`,
 1 AS `workload`,
 1 AS `workloadid`,
 1 AS `worder`,
 1 AS `ismain`,
 1 AS `result`,
 1 AS `ismedian`,
 1 AS `mode`,
 1 AS `extraopts`,
 1 AS `backend`,
 1 AS `filtered`,
 1 AS `buildid`,
 1 AS `deviceid`,
 1 AS `buildreleaseversion`,
 1 AS `backendid`,
 1 AS `branchid`,
 1 AS `day`,
 1 AS `source`,
 1 AS `lessisbetter`,
 1 AS `evaluatedby`,
 1 AS `int_build_num`,
 1 AS `build_type`,
 1 AS `JPSPrimary`,
 1 AS `build_comment`,
 1 AS `float_value`,
 1 AS `benchmark_internal_version`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_workloads_info`
--

DROP TABLE IF EXISTS `view_workloads_info`;
/*!50001 DROP VIEW IF EXISTS `view_workloads_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_workloads_info` AS SELECT 
 1 AS `benchmarkid`,
 1 AS `benchmark`,
 1 AS `version`,
 1 AS `workloadid`,
 1 AS `workload`,
 1 AS `order`,
 1 AS `ismain`,
 1 AS `lessisbetter`,
 1 AS `isKPI`,
 1 AS `float_value`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'perfdb'
--

--
-- Dumping routines for database 'perfdb'
--
/*!50003 DROP FUNCTION IF EXISTS `calc_fiveweeksold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` FUNCTION `calc_fiveweeksold`(`in_branch` INT, `in_backend` INT, `in_device` INT, `in_mode` VARCHAR(32), `in_weeksnum` INT) RETURNS varchar(32) CHARSET latin1
BEGIN
DECLARE lines_count INT(11);
DECLARE result_week VARCHAR(11);
select count(`data_builds`.`week`) into @lines_count  from `data_builds`
where `build_type` = "weekly"
AND `data_builds`.`branch` = `in_branch`
AND `data_builds`.`backend` = `in_backend`
AND `data_builds`.`device` = `in_device`
AND `data_builds`.`mode` = `in_mode`;

	IF `in_weeksnum` >= @lines_count THEN
      SET `in_weeksnum`=@lines_count -1;
    END IF;

select `data_builds`.`week` into @result_week from `data_builds`
where `build_type` = "isweekly"
AND `data_builds`.`branch` = `in_branch`
AND `data_builds`.`backend` = `in_backend`
AND `data_builds`.`device` = `in_device`
AND `data_builds`.`mode` = `in_mode`
order by week desc LIMIT `in_weeksnum`,1 ;

RETURN @result_week;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_to_variabilitytable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` PROCEDURE `add_to_variabilitytable`(IN buildidvar INT)
BEGIN

DELETE FROM `tmp_variabilityvalues` WHERE build = buildidvar;
insert into `tmp_variabilityvalues`(    SELECT 
        `data_builds`.`id` AS `build`,
        `data_builds`.`branch` AS `branch`,
        `data_builds`.`backend` AS `backend`,
        `data_builds`.`device` AS `device`,
        `data_builds`.`int_build_num` AS `int_build_num`,
        `data_builds`.`mode` AS `mode`,
        `data_builds`.`source` AS `source`,
        `data_results`.`benchmark` AS `benchmarkid`,
        `data_results`.`workload` AS `workloadid`,
		`list_workloads`.`order` AS `worder`,
	IF(ROUND((((MAX(`data_results`.`value`) - MIN(`data_results`.`value`)) * 200) / (MAX(`data_results`.`value`) + MIN(`data_results`.`value`))),
                2)<1,1.0,ROUND((((MAX(`data_results`.`value`) - MIN(`data_results`.`value`)) * 200) / (MAX(`data_results`.`value`) + MIN(`data_results`.`value`))),
                2)) AS `variability`
    FROM
        ((`data_results`
        JOIN ((`list_workloads`
        JOIN `list_devices`)
        JOIN `data_builds`) ON (((`list_devices`.`id` = `data_builds`.`device`)
            AND (`data_results`.`build` = `data_builds`.`id`)
            AND (`data_results`.`workload` = `list_workloads`.`id`))))
        JOIN `variability_weekparams` `weekparams`)
    WHERE
		
        ((`data_results`.`filtered` = 0)
			AND (`data_builds`.`id` = buildidvar)
            AND (`data_builds`.`branch` = `weekparams`.`branch`)
            AND (`data_builds`.`backend` = `weekparams`.`backend`)
            AND (`data_builds`.`device` = `weekparams`.`device`)
            AND (`data_builds`.`mode` = `weekparams`.`mode`)
--            AND (`data_builds`.`build_type` IN ('weekly' , 'daily', 'release'))
            )
    GROUP BY `data_builds`.`device` , `data_builds`.`branch` , `data_builds`.`backend` , `data_results`.`workload` , `data_results`.`benchmark` , `data_builds`.`week` , `data_builds`.`day` , `data_builds`.`extraopts` , `data_builds`.`mode` , `data_builds`.`source`);
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `calc_calculatable_scores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` PROCEDURE `calc_calculatable_scores`(`in_build` INT)
BEGIN

-- example:
/*
IF (SELECT count(*) FROM data_results WHERE build=`in_build` AND benchmark={benchmarkid} )>0  THEN
	DELETE FROM data_results WHERE build=`in_build` AND benchmark={benchmarkid} AND workload={workloadid} LIMIT 1;
	INSERT INTO data_results (build,workload,value,benchmark,ismedian) 
(SELECT build,{workloadid},EXP(SUM(LOG(value))/count(value)),{benchmarkid},1 FROM data_results WHERE build=`in_build` and ismedian=1 and workload in (
SELECT id FROM perfnew.list_workloads where benchmark={benchmarkid} and calculate=0));

END IF;
*/


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_currentvariabilitytable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` PROCEDURE `create_currentvariabilitytable`()
BEGIN
DROP TABLE IF EXISTS `tmp_currentvariabilityvalues`;
CREATE TABLE `tmp_currentvariabilityvalues` (
`variability` FLOAT NOT NULL,
`benchmark` tinyint NOT NULL,
`workload` int NOT NULL,
`worder` int NOT NULL,
`source` VARCHAR(10) NOT NULL,
`minvariability` FLOAT NOT NULL,
`maxvariability` FLOAT NOT NULL,
`int_build_num` int NOT NULL,
`branch` int NOT NULL,
`backend` int NOT NULL,
`device` int NOT NULL,
`mode` VARCHAR(10) NOT NULL
) ENGINE=InnoDB;


insert into `tmp_currentvariabilityvalues`( SELECT (AVG(`variability`)) AS `currvariability`,benchmark,workload,
worder,tmp_variabilityvalues.source,MIN(variability),MAX(variability),MAX(int_build_num),tmp_variabilityvalues.branch,tmp_variabilityvalues.backend,tmp_variabilityvalues.device,tmp_variabilityvalues.`mode`
FROM tmp_variabilityvalues, (SELECT MAX(int_build_num)-3 as build,branch,device,backend,`mode`,`source` FROM tmp_variabilityvalues GROUP BY branch,device,backend,`mode`,`source`) as minbuild
WHERE int_build_num >= minbuild.build AND tmp_variabilityvalues.branch = minbuild.branch AND tmp_variabilityvalues.device = minbuild.device AND tmp_variabilityvalues.backend = minbuild.backend AND tmp_variabilityvalues.`mode` = minbuild.`mode` AND tmp_variabilityvalues.`source` = minbuild.`source`
GROUP BY  `tmp_variabilityvalues`.`workload` ,  `tmp_variabilityvalues`.`mode` , `tmp_variabilityvalues`.`device`, 
`tmp_variabilityvalues`.`backend` , `tmp_variabilityvalues`.`branch` , `tmp_variabilityvalues`.`source`
ORDER BY source,worder);
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_variabilitytable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` PROCEDURE `create_variabilitytable`()
BEGIN
DROP TABLE IF EXISTS `tmp_variabilityvalues`;
CREATE TABLE `tmp_variabilityvalues` (
`build` int NOT NULL,
`branch` int NOT NULL,
`backend` int NOT NULL,
`device` int NOT NULL,
`int_build_num` int NOT NULL,
`mode` VARCHAR(10) NOT NULL,
`source` VARCHAR(10) NOT NULL,
`benchmark` tinyint NOT NULL,
`workload` int NOT NULL,
`worder` int NOT NULL,
`variability` FLOAT NOT NULL
) ENGINE=InnoDB;
insert into `tmp_variabilityvalues`( select * from `variability_foreachbuild`);
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_analyzeall` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`perfdbuser`@`%` PROCEDURE `proc_analyzeall`()
BEGIN
ANALYZE TABLE data_builds;
ANALYZE TABLE data_run_props;
ANALYZE TABLE data_hosts;
ANALYZE TABLE data_results;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `variability_foreachbuild`
--

/*!50001 DROP VIEW IF EXISTS `variability_foreachbuild`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`perfdbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `variability_foreachbuild` AS select `data_builds`.`id` AS `build`,`data_builds`.`branch` AS `branch`,`data_builds`.`backend` AS `backend`,`data_builds`.`device` AS `device`,`data_builds`.`int_build_num` AS `int_build_num`,`data_builds`.`mode` AS `mode`,`data_builds`.`source` AS `source`,`data_results`.`benchmark` AS `benchmarkid`,`data_results`.`workload` AS `workloadid`,`list_workloads`.`order` AS `worder`,round((((max(`data_results`.`value`) - min(`data_results`.`value`)) * 200) / (max(`data_results`.`value`) + min(`data_results`.`value`))),2) AS `variability` from ((`data_results` join ((`list_workloads` join `list_devices`) join `data_builds`) on(((`list_devices`.`id` = `data_builds`.`device`) and (`data_results`.`build` = `data_builds`.`id`) and (`data_results`.`workload` = `list_workloads`.`id`)))) join `variability_weekparams` `weekparams`) where ((`data_results`.`filtered` = 0) and (`data_builds`.`branch` = `weekparams`.`branch`) and (`data_builds`.`backend` = `weekparams`.`backend`) and (`data_builds`.`device` = `weekparams`.`device`) and (`data_builds`.`mode` = `weekparams`.`mode`) and (`data_builds`.`build_type` in ('weekly','daily','release'))) group by `data_builds`.`device`,`data_builds`.`branch`,`data_builds`.`backend`,`data_results`.`workload`,`data_results`.`benchmark`,`data_builds`.`week`,`data_builds`.`day`,`data_builds`.`extraopts`,`data_builds`.`mode`,`data_builds`.`source` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `variability_weekparams`
--

/*!50001 DROP VIEW IF EXISTS `variability_weekparams`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`perfdbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `variability_weekparams` AS select max(`maxweektbl`.`week`) AS `maxweek`,`calc_fiveweeksold`(`maxweektbl`.`branch`,`maxweektbl`.`backend`,`maxweektbl`.`device`,`maxweektbl`.`mode`,4) AS `minweek`,`maxweektbl`.`branch` AS `branch`,`maxweektbl`.`backend` AS `backend`,`maxweektbl`.`device` AS `device`,`maxweektbl`.`mode` AS `mode` from ((`data_builds` `maxweektbl` join `data_builds` `minweektbl`) join `variability_weeksubparams` `params`) where ((`maxweektbl`.`branch` = `params`.`branch`) and (`maxweektbl`.`build_type` = 'weekly') and (`maxweektbl`.`backend` = `params`.`backend`) and (`maxweektbl`.`device` = `params`.`device`) and (`maxweektbl`.`mode` = `params`.`mode`) and (`minweektbl`.`branch` = `params`.`branch`) and (`minweektbl`.`backend` = `params`.`backend`) and (`minweektbl`.`device` = `params`.`device`) and (`minweektbl`.`mode` = `params`.`mode`)) group by `maxweektbl`.`branch`,`maxweektbl`.`backend`,`maxweektbl`.`device`,`maxweektbl`.`mode` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `variability_weeksubparams`
--

/*!50001 DROP VIEW IF EXISTS `variability_weeksubparams`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`perfdbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `variability_weeksubparams` AS select `data_builds`.`branch` AS `branch`,`data_builds`.`backend` AS `backend`,`data_builds`.`device` AS `device`,`data_builds`.`mode` AS `mode` from `data_builds` where (`data_builds`.`build_type` = 'weekly') group by `data_builds`.`branch`,`data_builds`.`backend`,`data_builds`.`device`,`data_builds`.`mode` desc order by `data_builds`.`branch`,`data_builds`.`backend`,`data_builds`.`device`,`data_builds`.`mode` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_allresults`
--

/*!50001 DROP VIEW IF EXISTS `view_allresults`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`perfdbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_allresults` AS select `data_builds`.`build` AS `build`,`data_builds`.`year` AS `year`,`data_builds`.`week` AS `week`,`list_branches`.`name` AS `branch`,`list_devices`.`name` AS `device`,`list_devices`.`devicegroup` AS `devicegroup`,`data_run_props`.`directory` AS `directory`,`data_run_props`.`id` AS `directoryid`,`data_hosts`.`hostname` AS `hostname`,`list_benchmarks`.`name` AS `benchmark`,`list_benchmarks`.`id` AS `benchmarkid`,`list_benchmarks`.`version` AS `version`,`list_workloads`.`name` AS `workload`,`list_workloads`.`id` AS `workloadid`,`list_workloads`.`order` AS `worder`,`list_workloads`.`ismain` AS `ismain`,`data_results`.`value` AS `result`,`data_results`.`ismedian` AS `ismedian`,`data_builds`.`mode` AS `mode`,`data_builds`.`extraopts` AS `extraopts`,`list_backends`.`name` AS `backend`,`data_results`.`filtered` AS `filtered`,`data_results`.`build` AS `buildid`,`list_devices`.`id` AS `deviceid`,`data_builds`.`buildreleaseversion` AS `buildreleaseversion`,`data_builds`.`backend` AS `backendid`,`list_branches`.`id` AS `branchid`,`data_builds`.`source` AS `source`,`list_workloads`.`lessisbetter` AS `lessisbetter`,`list_workloads`.`criteria` AS `criteria`,`list_benchmarks`.`isKPI` AS `isKPI`,`list_workloads`.`group` AS `wgroup`,`data_builds`.`build_type` AS `build_type`,`list_workloads`.`float_value` AS `float_value` from ((`data_results` left join (((((`list_benchmarks` join `data_builds`) join `list_devices`) join `list_workloads`) join `list_backends`) join `list_branches`) on(((`data_results`.`benchmark` = `list_benchmarks`.`id`) and (`data_results`.`build` = `data_builds`.`id`) and (`data_builds`.`branch` = `list_branches`.`id`) and (`data_builds`.`backend` = `list_backends`.`id`) and (`data_builds`.`device` = `list_devices`.`id`) and (`data_results`.`workload` = `list_workloads`.`id`)))) left join (`data_run_props` join `data_hosts`) on(((`data_results`.`directory` = `data_run_props`.`id`) and (`data_run_props`.`host` = `data_hosts`.`id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_filteredresults`
--

/*!50001 DROP VIEW IF EXISTS `view_filteredresults`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`perfdbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_filteredresults` AS select `data_builds`.`build` AS `build`,`data_builds`.`year` AS `year`,`data_builds`.`week` AS `week`,`list_branches`.`name` AS `branch`,`list_devices`.`name` AS `device`,`list_devices`.`devicegroup` AS `devicegroup`,`data_run_props`.`directory` AS `directory`,`data_hosts`.`hostname` AS `hostname`,`list_benchmarks`.`name` AS `benchmark`,`list_benchmarks`.`id` AS `benchmarkid`,`list_benchmarks`.`version` AS `version`,`list_workloads`.`name` AS `workload`,`list_workloads`.`id` AS `workloadid`,`list_workloads`.`order` AS `worder`,`list_workloads`.`ismain` AS `ismain`,`data_results`.`value` AS `result`,`data_results`.`ismedian` AS `ismedian`,`data_builds`.`mode` AS `mode`,`data_builds`.`extraopts` AS `extraopts`,`list_backends`.`name` AS `backend`,`data_results`.`filtered` AS `filtered`,`data_results`.`build` AS `buildid`,`list_devices`.`id` AS `deviceid`,`data_builds`.`buildreleaseversion` AS `buildreleaseversion`,`data_builds`.`backend` AS `backendid`,`list_branches`.`id` AS `branchid`,`data_builds`.`day` AS `day`,`data_builds`.`source` AS `source`,`list_workloads`.`lessisbetter` AS `lessisbetter`,`data_builds`.`evaluatedby` AS `evaluatedby`,`data_builds`.`int_build_num` AS `int_build_num`,`data_builds`.`build_type` AS `build_type`,`list_workloads`.`JPSPrimary` AS `JPSPrimary`,`data_builds`.`comment` AS `build_comment`,`list_workloads`.`float_value` AS `float_value`,`data_results`.`benchmark_internal_version` AS `benchmark_internal_version` from (((((((`data_results` join `list_benchmarks`) join `data_builds`) join `list_devices`) join `list_workloads`) join `list_backends`) join `list_branches`) left join (`data_run_props` join `data_hosts`) on(((`data_results`.`directory` = `data_run_props`.`id`) and (`data_run_props`.`host` = `data_hosts`.`id`)))) where ((`data_results`.`benchmark` = `list_benchmarks`.`id`) and (`data_results`.`build` = `data_builds`.`id`) and (`data_builds`.`backend` = `list_backends`.`id`) and (`data_builds`.`branch` = `list_branches`.`id`) and (`data_builds`.`device` = `list_devices`.`id`) and (`data_results`.`workload` = `list_workloads`.`id`) and (`data_results`.`ismedian` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_workloads_info`
--

/*!50001 DROP VIEW IF EXISTS `view_workloads_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lab_aqa`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_workloads_info` AS select `list_benchmarks`.`id` AS `benchmarkid`,`list_benchmarks`.`name` AS `benchmark`,`list_benchmarks`.`version` AS `version`,`list_workloads`.`id` AS `workloadid`,`list_workloads`.`name` AS `workload`,`list_workloads`.`order` AS `order`,`list_workloads`.`ismain` AS `ismain`,`list_workloads`.`lessisbetter` AS `lessisbetter`,`list_benchmarks`.`isKPI` AS `isKPI`,`list_workloads`.`float_value` AS `float_value`,`list_benchmarks`.`enabled` AS `enabled` from (`list_workloads` join `list_benchmarks`) where (`list_workloads`.`benchmark` = `list_benchmarks`.`id`) order by `list_workloads`.`benchmark`,`list_workloads`.`order` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-15 17:08:09
